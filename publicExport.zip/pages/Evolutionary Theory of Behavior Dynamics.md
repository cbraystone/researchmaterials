---
title: Evolutionary Theory of Behavior Dynamics
tags:
categories:
date: 2022-06-30
lastMod: 2022-09-05
---
[[ABA]]

___

Actions

  + [[test]]
Type:: this
LOOKs:: Then

  + Type:: this
looks:: then

  + 

---

MTP's of action

  + J J McDowell, and Steven Riley. “IMPROVING ON SKINNER: AN EVOLUTIONARY THEORY OF BEHAVIOR DYNAMICS AND ITS NEURAL INTERPRETATION.” Behavior and philosophy 48 (2020): 18–24. Print.

    + [[article]][[ETBD]]

![jjmcdowell&RileyEvoluationaryTheory.pdf](/assets/jjmcdowell&rileyevoluationarytheory_1654385665210_0.pdf)

  + McDowell, J. J. “On the Current Status of the Evolutionary Theory of Behavior Dynamics.” Journal of the experimental analysis of behavior 111.1 (2019): 130–145. Web.

![J Exper Analysis Behavior - 2019 - McDowell - On the current status of the evolutionary theory of behavior dynamics.pdf](/assets/j_exper_analysis_behavior_-_2019_-_mcdowell_-_on_the_current_status_of_the_evolutionary_theory_of_behavior_dynamics_1654385763147_0.pdf)

  + Powerpoint presentation (from ABAI)

    + https://docs.google.com/presentation/d/1xALdeTJifP1R2hWPrIZEon6DTdsyoCpB/edit?usp=sharing&ouid=100570667705755710100&rtpof=true&sd=true

  + Executable File

    + https://www.dropbox.com/s/b97m9s3w8jl21ia/ETBD_Executable.zip?dl=0

    + 
